# MLSCAT

A small cat that helps you enjoy your side channel attack journey!

## Features

- Read Datasets: We provide a simple method to read some exist datasets(it would be better if there have the same structure!
- Cal Rank: try to give the key and result nparray
- Simple Attack: CPA, Correlation.
- quickly data preprocessing.

example:

```python
import mlscat as cat

print(cat.__version__)

# 0.1
```

## How to install❓

To install mlscat, just follow one steps:

`pip install mlscat`

## Benefits

- Reduce Workload.
- Increase hair volume.
