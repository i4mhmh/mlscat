from .api import get_sbox
from .ranks import rank
from .attacks import cpa, pcc, pearson

__name__ = "dlscat"
__version__ = '0.0.6'